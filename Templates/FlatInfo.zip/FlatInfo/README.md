# FlatInfo
For knowing informations and rating about flats and appartement
