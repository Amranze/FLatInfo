package com.flatinfo;

import java.net.UnknownHostException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MongodbTest {

	@Test
	public void checkUnique() throws UnknownHostException{
		MongoClient mongo;
		mongo = new MongoClient("localhost", 27017);
		DB db = mongo.getDB("test");
		DBCollection ownercollection = db.getCollection("ownerCollection");
		
		BasicDBObject userDBObject = new BasicDBObject();
		userDBObject.put("firstName", "Amrane");
		userDBObject.put("lastName", "Ait Zeouay");
		userDBObject.put("mail", "a.zeouayamran@gmail.com");
		userDBObject.put("username", "amraneze");
		userDBObject.put("password", "5454564564");
		userDBObject.put("birthdate", "30/03/1993");
		userDBObject.put("age", 23);
		userDBObject.put("phone", 75644845); 
		
		//ownercollection.insert(userDBObject);
		ownercollection.createIndex(new BasicDBObject("username", 1), "username", true);
		ownercollection.createIndex(new BasicDBObject("mail", 2), "mail", true);
		
		
		BasicDBObject userDBObject1 = new BasicDBObject();
		userDBObject1.put("firstName", "Amrane");
		userDBObject1.put("lastName", "Ait Zeouay");
		userDBObject1.put("mail", "a.zeouayamran@gmail.com");
		userDBObject1.put("username", "amranze");
		userDBObject1.put("password", "5454564564");
		userDBObject1.put("birthdate", "30/03/1993");
		userDBObject1.put("age", 23);
		userDBObject1.put("phone", 75644845); 

		ownercollection.insert(userDBObject1);

	}
	
}
