package com.flatinfo.Search;

public class SearchModel {

}
