package com.flatinfo.Entity.User;

public class SocialNetwork {
	private String fbUsername;
	private String fbUrl;
	private String linkedInUsername;
	private String linkedinUrl;
	private String twitterInUsername;
	private String TwitterUrl;
}
