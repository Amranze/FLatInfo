package com.flatinfo.Common;

public class PicturesSlideShow {

}
