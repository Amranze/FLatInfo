package com.flatinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlatInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlatInfoApplication.class, args);
	}
}
