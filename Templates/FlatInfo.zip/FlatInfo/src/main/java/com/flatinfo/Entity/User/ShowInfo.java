package com.flatinfo.Entity.User;

public class ShowInfo {
	private boolean phoneDisplayed;
	private boolean fbUrlDisplayed;
	private boolean linkedinUrlDisplayed;
	private boolean twitterDisplayed;
	private boolean adresseDisplayed;
	private boolean birthdateDisplayed;

}
