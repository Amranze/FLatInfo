package com.flatinfo.Entity.Flat;

public class Convenience {
	
	private boolean terrace;
	private boolean balcony;
	private boolean outdoorParking;
	private boolean box;
	private boolean cellar;
	private boolean fireplace;
	private boolean hardwoodFloors;
	private boolean elevator;
	private boolean lastStage;
	private boolean swimming_pool;
	private boolean cupboard;
	private boolean interCom;
	private boolean digicode;
	private boolean securityGuards;
	private boolean handicapAccess;
	private boolean alarm;
	
}
