package com.flatinfo.Common;

public class PictureHandler {
	/*public String pictureDecoder(String img){
		
	}
	
	public String pictureEncoder(){
		
	}*/

}
